#!/usr/bin/python
import fnmatch
import os
import time
import sys
# auto format by the command:
# autopep8 --in-place --aggressive --aggressive tof_2b.py
"""
 * dial.py
 *
 * Created on: 1 Nov 2010
 * Author:     Duncan Law
 *
 *      Copyright (C) 2010 Duncan Law
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *      Thanks to Chootair at http://www.codeproject.com/Members/Chootair
 *      for the inspiration and the artwork that i based this code on.
 *      His full work is intended for C# and can be found here:
 *      http://www.codeproject.com/KB/miscctrl/Avionic_Instruments.aspx




 * Requires pySerial and pyGame to run.
 * http://pyserial.sourceforge.net
 * http://www.pygame.org

"""
# serial port listing:  dmesg | grep tty

import math
from math import pi
import pygame
from pygame.locals import *
pygame.init()

from volknob import Volknob as Volknob
from volknob import TxSerial as TxSerial

def millisec():
    return int(round(time.time() * 1000))

# ====================================================================
# ====================================================================


serialPort = '/dev/ttyUSB0'
serialPort = '/dev/ttyACM0'
print ' '
print 'AIDP song control demo 20181015'
print '  m - stop/start music'
print '  b - enable/disable audible feedback beeps'
print ' '
print 'Port: ' + serialPort
baud = 115200

if (len(sys.argv) == 1):
    # No options used at run time. Presume serial port is "dev/ttyUSB0"
    test = 0
    #serialPort = '/dev/ttyUSB0'
elif (sys.argv[1] == 'test'):
    # Option "test" was selected. Run in test mode. (Dummy data used.)
    test = 1
else:
    # An option other that "test" was enterd. Maybe it's the Serial port.
    test = 0
    serialPort = sys.argv[1]

# Initialise Serial port.
ser = TxSerial(serialPort, baud, test)

# Initialise screen.
#screen = pygame.display.set_mode((640, 480))
screen = pygame.display.set_mode((307, 380))
screen.fill(0x222222)

# Initialise Dial.
volume = Volknob(0, 10, 307, 273)

# initialize strip chart
# https://stackoverflow.com/questions/557069/quick-and-dirty-stripchart-in-python
volvalue = 32
posprev = 0
a = 0
idx = 0
pause = 0
music_enable = 0
beep_enable = 1
t0 = millisec()
tvol = millisec()
tclick = millisec()
vol_state = 'vol_mid'
new_state = vol_state

#fnames = ["01 - Band On The Run.mp3",  "05 Dreamboat Annie.mp3", "04 Rhiannon.mp3", "13 - Blackbird.mp3", "04 - Two Hearts.mp3"]
# get file names of all mp3 files in this folder
#fnames = fnmatch.filter(os.listdir('.'), '*.mp3')
strpath = './mp3files/'
fnames = fnmatch.filter(os.listdir(strpath), '*.mp3')
nfiles = len(fnames)
mousebuttprev = pygame.mouse.get_pressed()

file = fnames[idx]
if(not test):
    pygame.display.set_caption('Bose AID&P Demo')
else:
    pygame.display.set_caption('Bose AID&P Demo Player - Test Mode')

# pygame.mixer.quit()
pygame.mixer.pre_init(22050, -16, 2, 2048)
pygame.init()
pygame.mixer.quit()
#pygame.mixer.init(22050, -16, 2, 4096)
pygame.mixer.init(22050, -16, 2, 512)
# pygame.mixer.init()
# pygame.init()

beep1 = pygame.mixer.Sound('./mp3files/beep1.wav')
beep2 = pygame.mixer.Sound('./mp3files/beep2.wav')
volbeepenable = 0

pygame.mixer.music.load(strpath + file)
if music_enable:
    pygame.mixer.music.play()
volume.update(screen, -90, 0, 0)
pygame.display.update()
pygame.mixer.music.set_volume(64)


while True:
    # -------------   Main program loop.   ----------------
    br_data = [0, 0]
    for event in pygame.event.get():
        if event.type == QUIT:
            print "Exiting...."
            ser.close()  # close serial port.
            sys.exit()   # end program.
            
        if event.type == pygame.KEYDOWN:  # if key pressed...
            inchar = event.key
            # print "key pressed  "
            # determine if a number key was pressed...
            if(inchar > pygame.K_0 and inchar <= pygame.K_9):
                ctrl = inchar - pygame.K_0
            else:
                ctrl = 0
            print "key pressed  ", ctrl
            br_data = [ctrl, 0]
            # if letter key pressed, mode change...
            if (inchar == pygame.K_x or inchar == pygame.K_m):
                if(music_enable == 1):
                    music_enable = 0
                    pygame.mixer.music.stop()
                    print "Music off."
                else:
                    music_enable = 1
                    pygame.mixer.music.play()
                    print "Music on."
            if (inchar == pygame.K_b):
                if(beep_enable == 1):
                    beep_enable = 0
                    print "Beeps off."
                    volume.overlay(
                        volume.greendot, 50, 50)  # =================
                else:
                    beep_enable = 1
                    print "Beeps on."
                    volume.overlay(
                        volume.blackdot, 50, 50)  # =================

    if(test):
        # Use dummy test data
        curPos = pygame.mouse.get_pos()

        mousebutt = pygame.mouse.get_pressed()
        if((mousebutt[0] == 1) and (mousebuttprev == 0)):
            posprev = curPos[0] / 1
#      print mousebutt
        if((curPos[0] / 1 - posprev) != 0 and mousebutt[0]):
            br_data[1] = curPos[0] / 1 - posprev
            br_data[1] = br_data[1] * 2
            posprev = curPos[0] / 1
            print curPos, br_data
        pygame.time.delay(50)
        mousebuttprev = mousebutt[0]
    else:
        # Get real data from USB port.
        br_data = ser.readline1()

#   pygame.mixer.music.set_volume(float(volvalue)/255)

    if(br_data):  # if we have data....
        #if(br_data[0] != 0):
            #print 'got data'
        if(br_data[1] != 0):
		# if(br_data[0] == 20 or br_data[1] == 21): # if volume change commands: 21=down, 20=up.
            # volvalue += br_data[1]/2 # for brooch
            # volvalue += br_data[1]/1 # for brooch
            # volvalue += br_data[1]*2 # for hart
            # volvalue += br_data[1]*2.5 # for TOF sensor
            # Volume change commands:  21 is down, 20 is up...
            volincrement = ((20 - br_data[0]) + 0.5) * 2  # direction sign
            volincrement *= br_data[1]  # aplpy increment
            if test:
                volincrement /= 8
            # volvalue += br_data[1]*2.5 # for TOF sensor
            volvalue += volincrement  # for TOF sensor
            if(volvalue > 255):
                volvalue = 255
            elif(volvalue < 5):
                volvalue = 5
            # print(br_data)
            vol_level = float(volvalue) / 255
            pygame.mixer.music.set_volume(vol_level)
            #print( " vol: %5.3f" % vol_level)

        # volume sound queues at reaching max and min...
        #print 'volvalue  ', volvalue, '  state ', vol_state, '  data ', br_data[1]
        if vol_state == 'vol_max':
            if volvalue < 255:
                new_state = 'vol_mid'
        if vol_state == 'vol_min':
            if volvalue > 5.5:
                new_state = 'vol_mid'
        if vol_state == 'vol_mid':
            if volvalue == 255:
                new_state = 'vol_max'
                tclick = millisec()
                if beep_enable:
                    bpvol = beep1.get_volume()
                    beep1.set_volume(1.0)
                    beep1.play(1)
                    time.sleep(0.250)
                    beep1.set_volume(bpvol)
            if volvalue < 5.5:
                new_state = 'vol_min'
                tclick = millisec()
                if beep_enable:
                    beep2.play(1)
        vol_state = new_state

        # music playing commands...
        # 1 play/pause, 2 skip for, 3 skip back
        # 4 hand start, 5 hand end, 6 hold start, 7 hold end
        ctrl = br_data[0]
        if(ctrl == 1):  # play/pause
            if(pause):
                if music_enable:
                    pygame.mixer.music.unpause()
                pause = 0
                if beep_enable:
                    beep1.play()
            else:
                if music_enable:
                    pygame.mixer.music.pause()
                pause = 1
                if beep_enable:
                    beep1.play()

        if (ctrl == 2):  # skip to next song
            if music_enable:
                idx += 1
                if(idx >= nfiles):
                    idx = 0  # wrap around
                pygame.mixer.music.stop()
                pygame.mixer.music.load(strpath + fnames[idx])
                pygame.mixer.music.play()
            if beep_enable:
                beep1.play(1)

        if (ctrl == 3):  # skip to prev song
            if music_enable:
                idx -= 1
                if(idx < 0):
                    idx = nfiles - 1  # wrap around
                pygame.mixer.music.stop()
                pygame.mixer.music.load(strpath + fnames[idx])
                pygame.mixer.music.play()
            if beep_enable:
                beep1.play(2)

        if (ctrl == 4 or ctrl == 5): # hand in or out
            if beep_enable:
                beep2.set_volume(1.0)
                beep2.play(0) # beep beep

        if (ctrl == 6): # hold start
            if beep_enable:
                beep1.set_volume(1.0)
                beep1.play(1) # beep beep
            volbeepenable = 1
            

        if (ctrl == 7 ): # hold end
        #if (ctrl == 200):  # beep while in volume change state
            tclick = millisec()
            if beep_enable:
                beep1.play()
                time.sleep(0.250)
                beep1.set_volume(0.3)
            volbeepenable = 0
            
                
        if (ctrl == 8):
            if beep_enable:
                beep2.set_volume(1.0)
                beep2.play(1) # boop boop
            volbeepenable = 0
        if (ctrl == 9):
            if beep_enable:
                beep2.set_volume(1.0)
                beep2.play(0) # boop boop
                time.sleep(0.15)
                beep1.play(0) # beep beep
            volbeepenable = 0
                 
                
        # Update dial image...
        if (ctrl != 0 or br_data[1] != 0):
            angle = (volvalue * 280) / 255 - 140
            volume.update(screen, angle, ctrl, pause)
            pygame.display.update()


    # if song ended, play next or wrap to first...
    if(not pygame.mixer.music.get_busy()):
        if music_enable:
            idx += 1
            if(idx >= nfiles):
                idx = 0
            pygame.mixer.music.load(strpath + fnames[idx])
            pygame.mixer.music.play()


    # beep continuously if enabled...
    if (millisec() - tclick > 750) and volbeepenable and beep_enable:
        #print 'time: ', t0
        beep1.play()
        tclick = millisec()

    while millisec() - t0 < 10:
        aaa = 5
    t0 = t0 + 10

#   elif not ser.testing:
#      # We do not have any data to display.
#      print " * No data received. Is the transmitter powered on?"
#      print " * Restarting " + serialPort + ".\n"
#      ser = TxSerial(serialPort, baud)


# ick@HP-ProBook-4530s ~/Desktop/cockpit1/cockpit $ sudo moserial
# rick@HP-ProBook-4530s ~/Desktop/cockpit1/cockpit $ sudo moserial
# rick@HP-ProBook-4530s ~/Desktop/cockpit1/cockpit $ sudo python volume.py /dev/ttyACM0
#['', '0', '0', '30', '\n']
